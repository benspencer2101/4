/* City Construction Dashboard – client logic */
/* eslint-env jquery */
/* @ai-assist ChatGPT adapted JS to integrate with get_projects.php */

$(document).ready(function () {
  // Fetch project data from PHP backend
  $.getJSON("api/get_projects.php", function (data) {
    let html = "<table border='1'><tr><th>Name</th><th>City</th></tr>";

    $.each(data, function (index, project) {
      html += "<tr>";
      html += "<td>" + project.name + "</td>";
      html += "<td>" + project.city + "</td>";
      html += "</tr>";
    });

    html += "</table>";

    // Inject into placeholder container
    $("#project-table").html(html);
  }).fail(function () {
    $("#project-table").html("<p style='color:red;'>⚠️ Could not load project data.</p>");
  });
});
