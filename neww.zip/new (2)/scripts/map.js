/* global google */
/* City Construction Dashboard | Google Maps logic
   @ai-assist ChatGPT helped modularise the pattern. ↂ AI-generated code ends. */

let map, marker;

/** Initialise map centred on Newcastle (first load). */
function initMap() {
  const defaultPos = { lat: 54.9784, lng: -1.6174 };
  map = new google.maps.Map(document.getElementById("map"), {
    zoom: 12,
    center: defaultPos,
  });
  marker = new google.maps.Marker({
    position: defaultPos,
    map,
    title: "Project location",
  });
}

/** Move the marker & centre the map on a new project. */
export function setProjectLocation(lat, lng, title) {
  const pos = { lat, lng };
  marker.setPosition(pos);
  marker.setTitle(title);
  map.panTo(pos);
}

/* Optional: expose init for Google callback */
window.initMap = initMap;
