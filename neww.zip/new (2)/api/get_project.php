<?php
$serverName = "tcp:kv6016bs.database.windows.net,1433";
$connectionOptions = array(
    "Database" => "CityProjectsDB",
    "Uid" => "CloudSA61c001f1",
    "PWD" => "Password1234",  // replace with the password you set
    "Encrypt" => true,
    "TrustServerCertificate" => false
);

$conn = sqlsrv_connect($serverName, $connectionOptions);
if (!$conn) {
    die(json_encode(array("error" => sqlsrv_errors())));
}

$sql = "SELECT * FROM Projects";
$stmt = sqlsrv_query($conn, $sql);
$rows = array();

while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    $rows[] = $row;
}

echo json_encode($rows);
?>
